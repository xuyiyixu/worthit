import {
  errorResponse,
  identity,
  readState,
  sameOrigin,
  sb,
} from "@/lib/server";
import { makeReading } from "@/lib/tarot";
import { localDay } from "@/lib/model";
import { z } from "zod";
const percent = z.number().int().min(0).max(100),
  id = z.string().uuid(),
  date = z.string().datetime();
const schemas = {
  profiles: z.object({
    name: z.string().trim().min(1).max(80),
    timezone: z
      .string()
      .max(80)
      .refine((v) => {
        try {
          new Intl.DateTimeFormat("en", { timeZone: v });
          return true;
        } catch {
          return false;
        }
      }),
    onboarded: z.boolean(),
    recovery: percent,
    groupSize: percent,
    strangerComfort: percent,
    spontaneity: percent,
    fomo: percent,
    boundaries: percent,
    support: percent,
  }),
  checkins: z.object({
    id,
    createdAt: date,
    social: percent,
    physical: percent,
    mood: z.enum(["Low", "Okay", "Good", "Great"]),
    stress: percent,
  }),
  decisions: z.object({
    id,
    createdAt: date,
    title: z.string().min(1).max(180),
    messages: z
      .array(
        z.object({
          id,
          role: z.enum(["user", "assistant"]),
          content: z.string().max(15000),
          mode: z.string().optional(),
          attachments: z
            .array(
              z.object({
                name: z.string().max(200),
                type: z.string().max(100),
                text: z.string().max(20000).optional(),
              }),
            )
            .max(3)
            .optional(),
        }),
      )
      .max(100),
    group: z.enum(["small", "large", "solo"]),
    people: z.enum(["friends", "strangers", "alone"]),
    duration: z.number().min(0).max(1440),
    batteryBefore: percent,
  }),
  outcomes: z.object({
    id,
    decisionId: id,
    createdAt: date,
    went: z.boolean(),
    enjoyment: z.number().min(1).max(10),
    after: percent,
    glad: z.boolean(),
    again: z.boolean(),
  }),
};
export async function GET(r: Request) {
  try {
    const { token, user } = await identity(r);
    return Response.json(await readState(token, user), {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (e) {
    return errorResponse(e, 401);
  }
}
export async function POST(r: Request) {
  try {
    sameOrigin(r);
    const { token, user } = await identity(r);
    const body = z
      .object({
        action: z.string().optional(),
        table: z.string().optional(),
        data: z.unknown(),
      })
      .parse(await r.json());
    if (body.action === "draw") {
      const state = await readState(token, user);
      if (!state.profile.onboarded)
        throw new Error("Complete your profile first.");
      const day = localDay(new Date(), state.profile.timezone);
      const reading = makeReading(state, day);
      const data = await sb("/rest/v1/rpc/draw_daily_tarot", token, {
        method: "POST",
        body: JSON.stringify({ p_data: reading }),
      });
      return Response.json(data);
    }
    const table = body.table as keyof typeof schemas;
    if (!Object.hasOwn(schemas, table)) throw new Error("Unknown record type");
    const data = schemas[table].parse(body.data);
    const record = {
      id: table === "profiles" ? user.id : "id" in data ? data.id : "",
      user_id: user.id,
      data,
      ...(table === "outcomes"
        ? { decision_id: "decisionId" in data ? data.decisionId : "" }
        : {}),
      ...(table === "profiles"
        ? {}
        : {
            created_at:
              "createdAt" in data ? data.createdAt : new Date().toISOString(),
          }),
    };
    await sb(`/rest/v1/${table}?on_conflict=id`, token, {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates" },
      body: JSON.stringify(record),
    });
    return Response.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
