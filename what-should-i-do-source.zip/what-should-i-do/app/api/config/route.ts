import { configured } from "@/lib/server";
export async function GET() {
  return Response.json(
    {
      auth: configured(),
      ai: !!process.env.NVIDIA_API_KEY,
      vision: !!(process.env.NVIDIA_API_KEY && process.env.NVIDIA_VISION_MODEL),
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
