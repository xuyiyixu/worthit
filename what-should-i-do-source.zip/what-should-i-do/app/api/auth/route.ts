import {
  configured,
  cookie,
  errorResponse,
  identity,
  sameOrigin,
  sb,
} from "@/lib/server";
import { z } from "zod";
const schema = z.object({
  action: z.enum(["login", "signup", "logout", "refresh"]),
  email: z.string().email().optional(),
  password: z.string().min(8).max(128).optional(),
  name: z.string().trim().min(1).max(80).optional(),
});
function sessionResponse(data: Record<string, unknown>, request: Request) {
  const headers = new Headers({
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  });
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  for (const [key, value, age] of [
    ["wsid-access", data.access_token, 3600],
    ["wsid-refresh", data.refresh_token, 2592000],
  ] as const) {
    headers.append(
      "Set-Cookie",
      `${key}=${value ?? ""}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${value ? age : 0}${secure}`,
    );
  }
  return new Response(
    JSON.stringify({
      user: data.user ?? null,
      message: data.access_token
        ? "Signed in"
        : "Check your email to confirm your account, then log in.",
    }),
    { headers },
  );
}
export async function GET(request: Request) {
  try {
    if (!configured()) return Response.json({ user: null });
    const { user } = await identity(request);
    return Response.json(
      { user },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json(
      { user: null },
      { headers: { "Cache-Control": "no-store" } },
    );
  }
}
export async function POST(request: Request) {
  try {
    sameOrigin(request);
    if (!configured())
      throw new Error(
        "Account sync is not configured. You can explore the demo instead.",
      );
    const body = schema.parse(await request.json());
    if (body.action === "logout") {
      const token = cookie(request, "wsid-access");
      try {
        if (token) await sb("/auth/v1/logout", token, { method: "POST" });
      } catch {}
      return sessionResponse({}, request);
    }
    if (body.action === "refresh") {
      const data = await sb("/auth/v1/token?grant_type=refresh_token", "", {
        method: "POST",
        body: JSON.stringify({
          refresh_token: cookie(request, "wsid-refresh"),
        }),
      });
      return sessionResponse(data, request);
    }
    if (!body.email || !body.password)
      throw new Error(
        "Enter your email and a password of at least 8 characters.",
      );
    const data = await sb(
      body.action === "signup"
        ? "/auth/v1/signup"
        : "/auth/v1/token?grant_type=password",
      "",
      {
        method: "POST",
        body: JSON.stringify({
          email: body.email,
          password: body.password,
          data: { name: body.name },
        }),
      },
    );
    return sessionResponse(data, request);
  } catch (e) {
    return errorResponse(e);
  }
}
