# What Should I Do?

A hackathon-ready social decision companion. Cream, lavender, and muted purple surfaces, an exclusively left-hand navigation, original typographic tarot cards, and responsive mobile drawers. Built with React 19, TypeScript, Next.js App Router conventions, and Vinext/Vite for Cloudflare-compatible hosting.

## Run locally

Requirements: Node.js 24 and pnpm 11.19.0 (or a compatible pnpm 11 release).

```sh
pnpm install --frozen-lockfile
cp .env.example .env.local
pnpm dev
```

Open http://localhost:5173. No external credentials are required. Click **Explore demo** for sample history, or **Sign Up → Start fresh in demo mode** to demonstrate onboarding. Demo records persist in this browser’s local storage. They are explicitly not authenticated accounts or cross-device storage. Signing out of the demo clears its local history.

```sh
pnpm typecheck
pnpm lint
pnpm test
# While the development server is running, without Supabase credentials:
node tests/api-smoke.mjs
pnpm build
pnpm start
```

The checked-in PDF.js worker must match the installed PDF.js version. When upgrading it, copy `node_modules/pdfjs-dist/build/pdf.worker.min.mjs` to `public/pdf.worker.min.mjs`. The worker is Apache-2.0; its license header is retained. No proprietary tarot images are used. Card names are traditional tarot names, with an original 78-card typographic design and original reflection text.

## The product

- **Home:** current battery, conversation shortcut, recent decisions, reflection links.
- **Profile:** seven one-time survey dimensions; editable name, review and retake. The dimensions are continuous 0–100 values, not personality diagnoses.
- **Global check-in:** social energy, physical energy, mood, stress, timestamped history.
- **Chat:** multiple conversations, follow-ups, explainable factors, text, PDFs, and images. Optional plans include going normally, going briefly, or skipping. Outcomes are the user’s decision, not a model command.
- **Feedback:** attendance, enjoyment, social battery afterward, glad they went, repeat intent. Users confirm group size, relationship category, and duration instead of treating inferred event details as facts.
- **Insights:** check-in history, enjoyment and energy impact by group, relationship category and duration, sample sizes, and survey/history weighting.
- **Tarot:** one saved daily draw of exactly three distinct cards; positions are Today’s Energy, Connection & Environment, Guidance. Saved interpretation, personal guidance, countdown and prior readings. This is a reflection feature, never factual prediction.
- **My Calendar:** intentionally a labeled placeholder, with no claim to know commitments or access Google Calendar.

## Architecture

```text
React UI + accessible Radix/Shadcn primitives
  ├── explicitly local demo → localStorage, browser draw lock
  └── authenticated account → same-origin API routes
         ├── Supabase Auth → HttpOnly session cookies
         ├── Supabase PostgREST → user JWT + Row Level Security
         └── NVIDIA NIM → optional vision extraction → Nemotron guidance
```

`app/page.tsx` owns the shared application state and the six sidebar views. `lib/model.ts` contains the domain model, seeded records, feature aggregation, and the deterministic demo responder. `lib/tarot.ts` contains the deck and reflection generation. `lib/client.ts` handles local persistence and attachment extraction. Server API routes keep provider keys out of the client bundle.

The SQL migration has separate per-user tables for profiles (including structured survey dimensions), check-ins, decisions (including conversation messages and event context), outcomes, and daily tarot readings. JSONB stores versionable record payloads, while ownership, timestamps, foreign keys, indexes, and daily uniqueness are relational. Outcome foreign keys include user ownership, so an outcome cannot reference another user’s decision.

### How personalization learns

Only attended events with linked outcomes contribute to enjoyment comparisons. The global history weight is `n / (n + 5)`. Demo guidance uses the same formula for matching group-size observations, blending recorded enjoyment with survey preference. Live guidance receives profile dimensions, current state, observed summaries, sample sizes, weights, and linked outcomes. Sparse samples are described as tentative; skipped events remain in history but do not fabricate enjoyment observations. This is contextual personalization, not model fine-tuning or a validated behavioral prediction model.

## Supabase setup

1. Create a Supabase project and enable email/password sign-in.
2. Run `supabase/migrations/001_social_companion.sql` once in the SQL editor (or use the Supabase migration CLI).
3. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `.env.local`. Use the publishable/anon key, **not** a service-role key.
4. Configure your application URL and redirect allowlist in Supabase Auth. With email confirmation enabled, the user confirms their email and returns to log in. For a controlled hackathon demo you may configure confirmation behavior in your project.
5. Restart the local server. Create an account, complete the seven questions, and save a check-in. Sign in with a second account to validate isolation before a public launch.

The app validates users through Supabase Auth on protected requests and sends their JWT to PostgREST. Row Level Security provides the authoritative ownership boundary. Cookies use HttpOnly, SameSite=Lax, and Secure on HTTPS; refresh runs on startup and periodically. Mutating requests reject cross-origin origins. Responses containing account state disable caching.

Daily readings are immutable to clients. `draw_daily_tarot` validates a server-current date in the profile timezone and three distinct valid cards, then inserts with `ON CONFLICT DO NOTHING` and returns the original draw. The unique `(user_id, local_date)` constraint handles concurrent devices. Timezone changes are blocked after the first saved draw to prevent timezone hopping. The account timezone is captured in the browser on initial onboarding. Demo draws use browser locks when available and the same saved-date check, but local storage can be cleared or altered by the device owner; demo mode is not an authoritative security boundary.

## NVIDIA Nemotron / NIM setup

Set these **server-side** environment variables:

```dotenv
NVIDIA_API_KEY=your-key
NVIDIA_BASE_URL=https://integrate.api.nvidia.com/v1
NVIDIA_MODEL=nvidia/llama-3.3-nemotron-super-49b-v1.5
NVIDIA_VISION_MODEL=nvidia/nemotron-nano-12b-v2-vl
ALLOW_DEMO_AI=false
```

Choose model identifiers available to your NVIDIA account; availability and quotas can vary. Requests use the OpenAI-compatible `/chat/completions` endpoint. A separate vision-capable model extracts event facts from images before the reasoning model sees them. Never set a text-only model as `NVIDIA_VISION_MODEL`.

By default only Supabase-authenticated requests use the API key. For a private, local hackathon demo without Supabase, set `ALLOW_DEMO_AI=true`. Keep it false for public hosting. When no key exists, the app uses a clearly labeled deterministic demo responder. Provider failures are shown without dropping the message; users can retry or explicitly choose demo guidance. No provider API call has been claimed as verified without credentials.

Text PDFs are extracted in the browser (up to 10 pages, 20,000 extracted characters, and a 5 MB total attachment budget). PNG, JPEG, and WebP files are accepted. Image bytes are sent only for live processing and not persisted; stored conversations retain filename/type and extracted PDF text. Scanned PDFs without text show a helpful error. Demo mode cannot interpret image contents and says so. Attachments are passed as untrusted event data, not model instructions.

Tarot interpretations intentionally use transparent card-theme templates personalized to the current battery/profile; they work independently of NIM and avoid presenting generative predictions as facts.

## Hackathon walkthrough (about 3 minutes)

1. Open **Explore demo** and show the six seeded outcomes and current 62% battery.
2. Update the battery to 25% to show a low-energy day.
3. In Chat, ask: “My friends invited me to a party, but I’m tired. Should I go?” Show the options, explicit factors, and follow-up conversation.
4. Attach a text event PDF to demonstrate extracted context; enable the vision model for image understanding.
5. Save a reflection. Verify Insights updates enjoyment, battery impact, and sample counts.
6. Draw the three tarot cards. Reload: the same reading remains and the redraw action is gone.
7. Show a prior sample reading and the Profile survey. For the onboarding demo, exit the demo, then choose **Start fresh in demo mode**.

## Deployment and verification

The project includes a Sites-compatible Worker build and `.openai/hosting.json`. Hosted secrets must be configured through the deployment platform; `.env.local` is not uploaded. Supabase migrations are external and must be applied to your Supabase project; they are not D1 migrations.

Automated checks cover deck completeness/uniqueness, random draw invariants, local calendar dates, daylight-saving rollover, outcome weighting, low-energy guidance, API validation, cross-origin rejection, and unauthenticated storage rejection. Browser checks cover demo chat/history, saved feedback, daily draw persistence, sidebar navigation, and responsive layouts. Live Supabase and NVIDIA calls need your credentials for final integration testing. Before opening a live-key deployment to the public, configure authentication abuse protection, provider budgets, and production rate limits appropriate to expected traffic.

Official integration references: [Supabase Auth](https://supabase.com/docs/guides/auth), [Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security), [NVIDIA NIM APIs](https://docs.api.nvidia.com/nim/re/reference/llm-apis), [NVIDIA vision API reference](https://docs.nvidia.com/nim/vision-language-models/1.5.0/api-reference.html).
