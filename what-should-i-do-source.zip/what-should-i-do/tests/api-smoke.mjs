import assert from "node:assert/strict";
const base = process.env.TEST_BASE_URL ?? "http://localhost:5173";
const profile = {
  name: "Test",
  timezone: "America/New_York",
  onboarded: true,
  recovery: 80,
  groupSize: 30,
  strangerComfort: 40,
  spontaneity: 40,
  fomo: 50,
  boundaries: 50,
  support: 50,
};
const state = {
  profile,
  checkins: [
    {
      social: 25,
      physical: 40,
      stress: 60,
      mood: "Okay",
      createdAt: new Date().toISOString(),
    },
  ],
  decisions: [],
  outcomes: [],
  readings: [],
};
const post = (body, origin = base) =>
  fetch(base + "/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: origin },
    body: JSON.stringify(body),
  });
const config = await (await fetch(base + "/api/config")).json();
assert.equal(typeof config.auth, "boolean");
let r = await post({
  demo: true,
  forceDemo: true,
  state,
  messages: [
    { id: "1", role: "user", content: "Should I go to a party tonight?" },
  ],
});
assert.equal(r.status, 200);
let result = await r.json();
assert.match(result.content, /25%/);
assert.match(result.content, /Go briefly/);
assert.equal(result.mode, "Demo guidance");
r = await post({
  demo: true,
  forceDemo: true,
  state,
  messages: [
    {
      id: "2",
      role: "user",
      content: "Help with this event",
      attachments: [
        {
          name: "event.pdf",
          type: "application/pdf",
          text: "Book club at 7 pm. Six friends. One hour.",
        },
      ],
    },
  ],
});
assert.match((await r.json()).content, /Book club at 7 pm/);
r = await post({ demo: true, state, messages: [] });
assert.equal(r.status, 400);
r = await post(
  { demo: true, state, messages: [{ id: "1", role: "user", content: "hi" }] },
  "https://untrusted.example",
);
assert.ok([400, 403].includes(r.status));
r = await fetch(base + "/api/data");
assert.equal(r.status, 401);
console.log(
  "API smoke checks passed: demo guidance, PDF context, validation, origin protection, unauthorized data access.",
);
