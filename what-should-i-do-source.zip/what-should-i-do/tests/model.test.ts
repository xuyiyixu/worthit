import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  demoState,
  emptyState,
  localDay,
  patternSummary,
  demoReply,
  minutesUntilNextDay,
} from "../lib/model.ts";
import { deck, makeReading } from "../lib/tarot.ts";
describe("social companion domain", () => {
  it("creates 78 distinct coherent tarot cards", () => {
    assert.equal(deck.length, 78);
    assert.equal(new Set(deck.map((c) => c.name)).size, 78);
  });
  it("draws exactly three distinct valid cards", () => {
    for (let i = 0; i < 100; i++) {
      const r = makeReading(emptyState());
      assert.equal(r.cards.length, 3);
      assert.equal(new Set(r.cards).size, 3);
      assert.ok(r.cards.every((c) => c >= 0 && c < 78));
      assert.match(r.guidance, /not predictions/);
    }
  });
  it("resolves calendar days by profile timezone across UTC midnight", () => {
    const date = new Date("2026-09-20T02:00:00Z");
    assert.equal(localDay(date, "America/New_York"), "2026-09-19");
    assert.equal(localDay(date, "Asia/Tokyo"), "2026-09-20");
  });
  it("weights observed outcomes increasingly and excludes skipped events", () => {
    const s = demoState();
    const base = patternSummary(s);
    assert.equal(base.observations, 6);
    assert.equal(base.smallEnjoyment, 9);
    assert.equal(base.largeEnjoyment, 6);
    assert.ok(base.historyWeight > 0.5);
    s.outcomes[0].went = false;
    assert.equal(patternSummary(s).observations, 5);
    assert.equal(patternSummary(emptyState()).historyWeight, 0);
  });
  it("handles a 23-hour daylight-saving day", () => {
    assert.equal(
      minutesUntilNextDay(new Date("2026-03-08T05:00:00Z"), "America/New_York"),
      1380,
    );
  });
  it("changes guidance when current energy is low", () => {
    const s = demoState();
    s.checkins[0].social = 10;
    assert.match(demoReply(s, []), /quiet evening/);
    assert.match(demoReply(s, []), /10%/);
  });
});
