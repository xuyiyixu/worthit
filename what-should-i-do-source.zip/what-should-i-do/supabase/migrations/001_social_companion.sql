-- Apply once in Supabase SQL Editor. No service-role key is used by the app.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  user_id uuid not null unique references auth.users(id) on delete cascade,
  data jsonb not null check (jsonb_typeof(data) = 'object'),
  created_at timestamptz not null default now(),
  check (id = user_id)
);
create table public.checkins (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  data jsonb not null check (jsonb_typeof(data) = 'object'),
  created_at timestamptz not null default now()
);
create table public.decisions (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  data jsonb not null check (jsonb_typeof(data) = 'object'),
  created_at timestamptz not null default now(),
  unique (id, user_id)
);
create table public.outcomes (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  decision_id uuid not null,
  data jsonb not null check (jsonb_typeof(data) = 'object'),
  created_at timestamptz not null default now(),
  unique (decision_id, user_id),
  foreign key (decision_id, user_id) references public.decisions(id, user_id) on delete cascade
);
create table public.tarot_readings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  local_date date not null,
  data jsonb not null check (jsonb_array_length(data->'cards') = 3),
  created_at timestamptz not null default now(),
  unique (user_id, local_date)
);
create index checkins_user_time on public.checkins(user_id, created_at desc);
create index decisions_user_time on public.decisions(user_id, created_at desc);
create index outcomes_user_time on public.outcomes(user_id, created_at desc);
create index readings_user_time on public.tarot_readings(user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.checkins enable row level security;
alter table public.decisions enable row level security;
alter table public.outcomes enable row level security;
alter table public.tarot_readings enable row level security;
create policy owner_profile on public.profiles for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy owner_checkins on public.checkins for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy owner_decisions on public.decisions for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy owner_outcomes on public.outcomes for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy owner_readings on public.tarot_readings for select to authenticated using (user_id = (select auth.uid()));
revoke all on public.profiles, public.checkins, public.decisions, public.outcomes, public.tarot_readings from anon;
grant select, insert, update, delete on public.profiles, public.checkins, public.decisions, public.outcomes to authenticated;
revoke insert, update, delete on public.tarot_readings from authenticated;
grant select on public.tarot_readings to authenticated;

-- Timezone is fixed once the first reading is recorded, preventing timezone hopping.
create function public.protect_reading_timezone() returns trigger language plpgsql set search_path = '' as $$
begin
  if old.data->>'timezone' is distinct from new.data->>'timezone' and exists(select 1 from public.tarot_readings where user_id = old.user_id) then
    raise exception 'The daily reading timezone cannot change after your first draw';
  end if;
  return new;
end $$;
create trigger preserve_reading_timezone before update on public.profiles for each row execute function public.protect_reading_timezone();

-- Atomic first-write-wins. Concurrent calls always return the originally saved draw.
create function public.draw_daily_tarot(p_data jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  owner uuid := auth.uid(); tz text; day date; result jsonb; card_count integer;
begin
  if owner is null then raise exception 'Authentication required'; end if;
  select data->>'timezone' into tz from public.profiles where user_id = owner and data->>'onboarded' = 'true';
  if tz is null then raise exception 'Complete your profile first'; end if;
  day := (now() at time zone tz)::date;
  if p_data->>'date' <> day::text then raise exception 'Reading date must be today in your profile timezone'; end if;
  if jsonb_array_length(p_data->'cards') <> 3 then raise exception 'Exactly three cards required'; end if;
  select count(distinct v::integer) into card_count from jsonb_array_elements_text(p_data->'cards') v where v::integer between 0 and 77;
  if card_count <> 3 then raise exception 'Three distinct valid cards required'; end if;
  insert into public.tarot_readings(user_id,local_date,data) values(owner,day,p_data)
    on conflict(user_id,local_date) do nothing;
  select data into result from public.tarot_readings where user_id=owner and local_date=day;
  return result;
end $$;
revoke all on function public.draw_daily_tarot(jsonb) from public, anon;
grant execute on function public.draw_daily_tarot(jsonb) to authenticated;
