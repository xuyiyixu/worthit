import { AppState, Attachment, Reading } from "./model";
import { makeReading } from "./tarot";
export const DEMO_KEY = "wsid-demo-v1";
export function api(
  path: "/api/config",
): Promise<{ auth: boolean; ai: boolean; vision: boolean }>;
export function api(
  path: "/api/auth",
  body?: unknown,
): Promise<{ user: { id: string; email?: string } | null; message: string }>;
export function api(path: "/api/data"): Promise<AppState>;
export function api(
  path: "/api/data",
  body: { action: "draw" },
): Promise<Reading>;
export function api(path: "/api/data", body: unknown): Promise<{ ok: boolean }>;
export function api(
  path: "/api/chat",
  body: unknown,
): Promise<{ content: string; mode: string }>;
export async function api(path: string, body?: unknown): Promise<unknown> {
  const response = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: body ? { "Content-Type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = (await response.json()) as { error?: string };
  if (!response.ok) throw new Error(data.error ?? "Please try again.");
  return data;
}
export function persistDemo(state: AppState) {
  localStorage.setItem(DEMO_KEY, JSON.stringify(state));
}
export async function drawDemo(state: AppState): Promise<Reading> {
  const draw = () => {
    const latest = JSON.parse(
      localStorage.getItem(DEMO_KEY) ?? JSON.stringify(state),
    ) as AppState;
    const next = makeReading(latest);
    const existing = latest.readings.find((r) => r.date === next.date);
    if (existing) return existing;
    latest.readings.unshift(next);
    persistDemo(latest);
    return next;
  };
  if (navigator.locks) return navigator.locks.request("wsid-daily-draw", draw);
  return draw();
}
export async function readAttachment(file: File): Promise<Attachment> {
  if (file.size > 5 * 1024 * 1024)
    throw new Error("Choose a file smaller than 5 MB.");
  if (file.type === "application/pdf") {
    const pdfjs = await import("pdfjs-dist");
    pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
    const task = pdfjs.getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
    });
    const pdf = await task.promise;
    try {
      if (pdf.numPages > 10)
        throw new Error("Please upload a PDF with 10 pages or fewer.");
      let text = "";
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        text +=
          content.items
            .map((item) => ("str" in item ? item.str : ""))
            .join(" ") + "\n";
      }
      if (!text.trim())
        throw new Error(
          "This PDF has no readable text. Upload an image of the event or describe it.",
        );
      return { name: file.name, type: file.type, text: text.slice(0, 20000) };
    } finally {
      await task.destroy();
    }
  }
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type))
    throw new Error("Use a PNG, JPG, WebP, or PDF.");
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read the file."));
    reader.readAsDataURL(file);
  });
  return { name: file.name, type: file.type, dataUrl };
}
