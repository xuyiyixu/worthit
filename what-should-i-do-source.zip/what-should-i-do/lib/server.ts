import { AppState, emptyState } from "./model";
export const configured = () =>
  !!(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY);
export const cookie = (r: Request, key: string) =>
  r.headers
    .get("cookie")
    ?.split("; ")
    .find((x) => x.startsWith(key + "="))
    ?.slice(key.length + 1) ?? "";
export function sameOrigin(r: Request) {
  const origin = r.headers.get("origin");
  if (origin && origin !== new URL(r.url).origin)
    throw new Error("Cross-origin request rejected");
}
export async function sb(path: string, token = "", init: RequestInit = {}) {
  const response = await fetch(`${process.env.SUPABASE_URL}${path}`, {
    ...init,
    headers: {
      apikey: process.env.SUPABASE_ANON_KEY ?? "",
      Authorization: `Bearer ${token || process.env.SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      ...init.headers,
    },
    signal: AbortSignal.timeout(15000),
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok)
    throw new Error(
      data?.msg ??
        data?.message ??
        data?.error_description ??
        "Account storage unavailable",
    );
  return data;
}
export async function identity(r: Request) {
  if (!configured()) throw new Error("Supabase is not configured");
  const token = cookie(r, "wsid-access");
  if (!token) throw new Error("Please log in again");
  const user = await sb("/auth/v1/user", token);
  if (!user?.id) throw new Error("Please log in again");
  return { token, user };
}
export async function readState(
  token: string,
  user: { id: string; user_metadata?: { name?: string } },
): Promise<AppState> {
  const tables = [
    "profiles",
    "checkins",
    "decisions",
    "outcomes",
    "tarot_readings",
  ];
  const rows = await Promise.all(
    tables.map((t) =>
      sb(
        `/rest/v1/${t}?user_id=eq.${user.id}&select=data&order=created_at.desc`,
        token,
      ),
    ),
  );
  const state = emptyState(user.user_metadata?.name ?? "Friend");
  if (rows[0][0]) state.profile = rows[0][0].data;
  state.checkins = rows[1].map((r: { data: unknown }) => r.data);
  state.decisions = rows[2].map((r: { data: unknown }) => r.data);
  state.outcomes = rows[3].map((r: { data: unknown }) => r.data);
  state.readings = rows[4].map((r: { data: unknown }) => r.data);
  return state;
}
export function errorResponse(e: unknown, status = 400) {
  return Response.json(
    {
      error:
        e instanceof Error
          ? e.message
          : "Something went wrong. Please try again.",
    },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}
